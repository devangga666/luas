<DOCTYPE! html>
    <head>
        <title>
            Perhitungan Luas Segitiga
        </title>
    </head>
<body>
        <form action="http://localhost/segitiga/index.php/Control/proses" method="POST">
    <h1>Menghitung Luas Segitiga Menggunakan CodeIgniter</h1>
    </br>
    <table border="1">
    <tr>
    <td><h2>Isi Data</h2></td>
    </tr>
    <tr>
    <td>Alas Segitiga</td>
    <td><input type="text" name="alas" required>
    </tr>
    <tr>
    <td>Tinggi Segitiga</td>
    <td><input type="text" name="tinggi" required>
    </tr>
    <tr>
    <td><input type="submit" name="submit" value="hitung"></td>
    </tr>
    </table>
        </form>  
</body>
</html>

