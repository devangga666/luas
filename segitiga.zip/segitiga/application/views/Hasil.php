<DOCTYPE! html>
<head>
    <title>Hasil Perhitungan</title>
</head>
<body>
<table border="1">
<tr>
    <td><?php echo "alas = $alas"; ?></td>
    <td><?php echo "tinggi = $tinggi"; ?></td>
    <td><?php echo "luas = $luas_segitiga"; ?></td>
    </tr>
    </table>
</body>
</html>