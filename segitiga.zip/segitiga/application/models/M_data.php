<?php

    Class M_data extends CI_Model{
        function index(){
        return $this->db->get('segitiga');
        }
        function akhir(){
            return $this->db->get('segitiga');
        }
    }