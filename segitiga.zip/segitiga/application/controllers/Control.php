<?php  

 Class Control extends CI_Controller{
     public function index(){
         $this->load->view('Home');
     }
     public function proses(){
        $alas = $this->input->post('alas');
        $tinggi =$this->input->post('tinggi');

        if($this->input->post('submit')){
            $luas_segitiga = 1/2*($alas*$tinggi);
        }
        $data=array(
            'alas' => $alas,
            'tinggi' => $tinggi,
            'luas_segitiga' => $luas_segitiga

            
        );
        $this->load->view('Hasil',$data);

     }
 }